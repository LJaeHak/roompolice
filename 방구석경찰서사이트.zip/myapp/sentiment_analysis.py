# myapp/sentiment_analysis.py
import pickle
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import numpy as np
from konlpy.tag import Okt
from tensorflow.keras.models import load_model
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm  # 폰트 관리자 추가
import json
import nltk
import time
import io
import base64

# 폰트 경로 설정 (환경에 따라 변경)
FONT_PATH = "C:/Windows/Fonts/malgun.ttf"  # Windows: 맑은 고딕

# 모델 및 데이터 경로 설정
MODEL_PATH = 'D:/python/CapstoneDesign-master/mod/emotional_analysis.h5'
TOKENS_PATH = 'D:/python/CapstoneDesign-master/mod/tokens.txt'
TRAIN_DOCS_PATH = 'D:/python/CapstoneDesign-master/mod/train_docs.json'
CHROME_DRIVER_PATH = 'D:/develop/dw/chromedriver-win64/chromedriver-win64/chromedriver.exe'

def load_sentiment_model():
    """감정 분석 모델 및 데이터 로드"""
    with open(TRAIN_DOCS_PATH, encoding="utf-8") as f:
        train_docs = json.load(f)
    with open(TOKENS_PATH, 'rb') as file:
        tokens = pickle.load(file)
    model = load_model(MODEL_PATH)
    okt = Okt()
    selected_words = [f[0] for f in nltk.Text(tokens, name='NMSC').vocab().most_common(10000)]
    return model, okt, selected_words

def fetch_comments(url):
    """URL에서 댓글 수집"""
    options = webdriver.ChromeOptions()
    options.add_argument("headless")
    service = Service(CHROME_DRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=options)
    driver.get(url)

    comments = []

    # 댓글 보기 버튼 클릭
    try:
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".u_cbox_btn_view_comment"))
        ).click()
    except:
        print("댓글 버튼을 찾을 수 없습니다.")
        driver.quit()
        return comments

    # 더보기 버튼 반복 클릭
    while True:
        try:
            more_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".u_cbox_btn_more"))
            )
            more_button.click()
            time.sleep(0.5)
        except:
            break  # 더 이상 "더보기" 버튼이 없으면 종료

    # 로드된 댓글 수집
    soup = BeautifulSoup(driver.page_source, "lxml")
    comment_elements = soup.find_all("span", {"class": "u_cbox_contents"})
    for comment in comment_elements:
        comments.append(comment.text)
    driver.quit()
    
    print("Collected Comments:", comments)  # 수집된 댓글 출력
    return comments

def predict_sentiment(comment, model, okt, selected_words):
    """단일 댓글의 감정 예측"""
    token = ['/'.join(t) for t in okt.pos(comment, norm=True, stem=True)]
    term_frequencies = [token.count(word) for word in selected_words]
    data = np.expand_dims(np.asarray(term_frequencies).astype('float32'), axis=0)
    score = float(model.predict(data))
    return "긍정" if score > 0.5 else "부정"

def analyze_comments(url):
    """URL의 댓글 분석"""
    comments = fetch_comments(url)
    model, okt, selected_words = load_sentiment_model()
    results = { "긍정": 0, "부정": 0 }
    detailed_comments = []  # 감정 분석 결과 포함한 댓글 리스트

    for comment in comments:
        sentiment = predict_sentiment(comment, model, okt, selected_words)
        results[sentiment] += 1
        detailed_comments.append({"text": comment, "sentiment": sentiment})  # 감정 결과 추가

    # 수집된 댓글 목록과 긍정/부정 댓글 수 및 세부 댓글 데이터 반환
    return {
        "comments": comments,
        "detailed_comments": detailed_comments,  # 감정 분석 결과 포함한 댓글 리스트
        "긍정": results["긍정"],
        "부정": results["부정"]
    }


def generate_sentiment_chart(results):
    """악성 댓글 시각화 차트 생성"""
    labels = ['긍정', '부정']
    sizes = [results['긍정'], results['부정']]
    colors = ['#ff9999', '#66b3ff']
    explode = (0.1, 0)  # 부정을 강조
    
    # 한글 폰트 설정
    font_prop = fm.FontProperties(fname=FONT_PATH)
    
    plt.figure(figsize=(6, 6))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140, colors=colors, explode=explode, textprops={'fontproperties': font_prop})
    plt.title('악성 댓글 시각화', fontproperties=font_prop)
    
    # 이미지를 base64로 변환
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    plt.close()
    return image_base64

def generate_wordcloud(comments, negative_only=False):
    """댓글 워드클라우드 생성 (부정 댓글만 포함 가능)"""
    if negative_only:
        # 부정 댓글만 필터링
        comments = [comment for comment in comments if comment['sentiment'] == "부정"]
        text = ' '.join([comment['text'] for comment in comments])
    else:
        # 모든 댓글 사용
        text = ' '.join(comments)

    wordcloud = WordCloud(width=800, height=400, background_color='black', colormap='viridis', font_path=FONT_PATH).generate(text)
    
    # 이미지를 base64로 변환
    buf = io.BytesIO()
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    plt.close()
    return image_base64

