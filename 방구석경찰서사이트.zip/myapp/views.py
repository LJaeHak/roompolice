# myapp/views.py
from django.shortcuts import render
from .sentiment_analysis import analyze_comments, generate_sentiment_chart, generate_wordcloud

def analyze_view(request):
    if request.method == "POST":
        url = request.POST.get('url')  # 사용자가 입력한 URL 가져오기
        analysis_results = analyze_comments(url)  # 댓글 분석 결과 가져오기

        # 시각화 차트 생성
        chart_image = generate_sentiment_chart(analysis_results)  # 긍정/부정 비율 시각화

        # 부정 댓글만 포함된 워드클라우드 생성
        wordcloud_image = generate_wordcloud(analysis_results["detailed_comments"], negative_only=True)

        return render(request, "myapp/analyze_results.html", {
            "url": url,
            "comments": analysis_results["comments"],  # 수집된 댓글
            "긍정": analysis_results["긍정"],  # 긍정 댓글 수
            "부정": analysis_results["부정"],  # 부정 댓글 수
            "chart_image": chart_image,  # 시각화 차트 이미지
            "wordcloud_image": wordcloud_image  # 부정 댓글 워드클라우드 이미지
        })
    return render(request, "myapp/analyze_form.html")
